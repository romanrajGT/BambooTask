﻿namespace Nop.Plugin.Custom.Discounts;

/// <summary>
/// Represents constants for the discount requirement rule
/// </summary>
public static class DiscountRequirementDefaults
{
    public const string SYSTEM_NAME = "Custom.Discounts";
}
